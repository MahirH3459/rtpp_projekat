# rtpp.projekat
Projektni tim za Projekat 2 - vođenje evidencija potrošnje office-a      
Članovi tima: Mujo Alić, Hasan Avdić, Mahir Halilović, Haris Vikalo, Ehilmana Beganović  
Za Sprint 0 je Product Owner - Edin Ahmetbegović i Scrum Master - Emina Jusufović

Ime tima: Šoldy  
Vođa tima: Mujo Alić      
Način komunikacije unutar tima: Facebook Messenger (quick updates) i Discord (work sessions) 
  
FIGMA MOCKUP DESIGN: https://www.figma.com/design/IV4r8BYNYd0j2BIlpiNvn1/Soldy?node-id=2-2&t=JUMUVBMcJeqgazJE-1&fbclid=IwZXh0bgNhZW0CMTEAAR2SCnK6s8p_l50s3mCgkp9_8nqpYA0AwOARuCUm2C14E51nhwJ7OtMSShE_aem_53eziCUXef0g2F6e8vT_UQ

Jira projekat: https://l.facebook.com/l.php?u=https%3A%2F%2Ffet-rtpp-project2.atlassian.net%2Fjira%2Fsoftware%2Fprojects%2FSOLDY%2Fboards%2F2%2Fbacklog%3Fassignee%3Dunassigned%26fbclid%3DIwZXh0bgNhZW0CMTEAAR3vnS1oFOEgEDO6fSw-VAGPi2KsNrJjDzQhp5NTBMomCgV9swfST74iR2I_aem_ix6GNQvskN1e3v-C57u8Vw&h=AT2tTjgGDqg8Km03g-_wXCeKX5mPr0JkXC6iSz01fatTPfYDaXSsZxKBfMu3jF6lJ9y2q__mnsLvuN6QKgTAe7MafHGi3d29Eo9mJQIWKZKeEBt5UuSlxOaqkoJnVdo&s=1

MVP izvjestaj: https://docs.google.com/document/d/1vcy9y4f7RYSajwKvTvXZEqzPa7zw5FLjJLrdbkDve0w/edit?tab=t.0#heading=h.ik2hr5w3dlzu
