Sprint 0 Retrospektiva  

Hasan Avdić    
Šta je dobro prošlo? Uspješno sam postavio privatni GitHub repozitorij, dodao sve članove i osigurao da svi mogu nesmetano raditi. Također, izradio sam završni izvještaj, što je omogućilo timsku refleksiju na sprint.  
Koji su izazovi uočeni? Povremeno je bilo potrebno dodatno usklađivanje kod dodavanja članova, ali je to riješeno kroz brzu komunikaciju.  
Kako poboljšati proces u Sprintu 1? Može se unaprijediti organizacija repozitorija tako da se jasno definišu folderi i pravila commitovanja.  

Mahir Halilović  
Šta je dobro prošlo? Mahir je detaljno razradio projektne zahtjeve i pomogao u definisanju MVP-a, osiguravajući da svi ključni aspekti budu obuhvaćeni.  
Koji su izazovi uočeni? Bilo je potrebno dodatno konsultovanje sa ostatkom tima kako bi se osiguralo da su svi zahtjevi usklađeni s tehničkim mogućnostima.  
Kako poboljšati proces u Sprintu 1? Unaprijediti način prikupljanja korisničkih zahtjeva kroz ankete ili dodatne sastanke sa potencijalnim korisnicima.  

Haris Vikalo  
Šta je dobro prošlo? Haris je pokazao preciznost u definisanju projektnih zahtjeva i MVP-a, pomažući timu da stekne jasnu sliku o funkcionalnostima aplikacije.  
Koji su izazovi uočeni? Povremeno je bilo neophodno dodatno razjašnjenje pojedinih zahtjeva, ali su svi eventualni nesporazumi brzo riješeni.  
Kako poboljšati proces u Sprintu 1? Može se uvesti vizuelna prezentacija zahtjeva (npr. dijagrami toka) kako bi se olakšalo razumijevanje.  

Ehilmana Beganović  
Šta je dobro prošlo? Ehilmana je uspješno postavila Jira projekat i dodala sve članove, omogućavajući timu da efikasno prati zadatke i napredak.  
Koji su izazovi uočeni? Početna konfiguracija Jira sistema zahtijevala je istraživanje kako bi se optimalno postavila struktura taskova, ali je sve uspješno implementirano.  
Kako poboljšati proces u Sprintu 1? Moguće je definisati jasnije workflow statuse kako bi svi članovi lakše pratili napredak zadataka.  

Mujo Alić  
Šta je dobro prošlo? Mujo je odradio odličan posao u izradi maketa i wireframe-ova, omogućavajući timu vizuelni prikaz aplikacije još u ranoj fazi razvoja.  
Koji su izazovi uočeni? Bilo je potrebno nekoliko iteracija da se makete usklade sa funkcionalnim zahtjevima, ali je krajnji rezultat bio uspješan.  
Kako poboljšati proces u Sprintu 1? Može se ranije prikupiti feedback od tima kako bi se smanjio broj iteracija prilikom izrade novih wireframe-ova.  
