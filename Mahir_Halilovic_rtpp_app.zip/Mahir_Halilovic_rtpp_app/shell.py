from rtpp_app import create_app
from rtpp_app.extensions import db
from rtpp_app.models.user import User

app = create_app()
app.app_context().push()

print(db.engine.url)
print(">>> Shell je spreman. Možeš koristiti: db, User itd.")

user = User.query.filter_by(email="mahir.halilovic1@fet.ba").first()

# Ako ga nađeš, postavi novu lozinku
user.set_password("M3+6/q")

#u1 = User(email="mujo.alic@fet.ba", role="admin")
#u2 = User(email="hasan.avdic@fet.ba", role="admin")
#u3 = User(email="haris.vikalo@fet.ba", role="admin")
#u4 = User(email="ehlimana.beganovic@fet.ba", role="admin")
#u5 = User(email="e@e.com", role="employee")
#u6 = User(email="f@f.com", role="employee")

#u1.set_password("G4(h-*")
#u2.set_password("m0A/c4")
#u3.set_password("Ab4v+0")
#u4.set_password("05f!9F")
#u5.set_password("#f7K*c")
#u6.set_password("G&vZ&T")

#db.session.add_all([u1, u2, u3, u4, u5, u6])
db.session.commit()
