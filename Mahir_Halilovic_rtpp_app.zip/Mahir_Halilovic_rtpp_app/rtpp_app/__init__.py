from flask import Flask
from config import Config
from flask_migrate import Migrate
from rtpp_app.extensions import db, login_manager
from rtpp_app.models.user import User
from flask import redirect, url_for, render_template
from flask_login import current_user

login_manager.login_view = 'auth.login'   # preusmjeri neulogirane na auth.login
migrate = Migrate()

def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')
    app.config.from_object(Config)

    # init ekstenzija za bazu
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    # blueprints
    from rtpp_app.routes.auth import auth_bp
    app.register_blueprint(auth_bp)


    @app.route('/')
    def home():
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        else:
            return render_template('home.html')  # stranicu koju želiš za prijavljene


    return app
