from flask import Blueprint

main = Blueprint('main', __name__)

from .auth import auth_bp
main.register_blueprint(auth_bp)

