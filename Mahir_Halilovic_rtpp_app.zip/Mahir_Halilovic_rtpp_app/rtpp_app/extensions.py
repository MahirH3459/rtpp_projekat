# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 23:31:17 2025

@author: WIN10
"""

# rtpp_app/extensions.py

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
